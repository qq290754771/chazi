<?php
/*
 * @Title:
 * @Author: wzs
 * @Date: 2020-04-09 15:15:43
 * @LastEditors: wzs
 * @LastEditTime: 2020-07-29 15:16:08
 * @Description:
 */
return
array (
  'type' => 'mysql',
  'hostname' => 'localhost',
  'database' => 'newphp',
  'username' => 'root',
  'password' => 'root',
  'hostport' => '3306',
  'dsn' => '',
  'params' =>
  array (
  ),
  'charset' => 'utf8',
  'prefix' => 'cool_',
  'debug' => true,
  'deploy' => 0,
  'rw_separate' => false,
  'master_num' => 1,
  'slave_no' => '',
  'fields_strict' => false,
  'resultset_type' => 'array',
  'auto_timestamp' => false,
  'datetime_format' => 'Y-m-d H:i:s',
  'sql_explain' => false,
)
;
