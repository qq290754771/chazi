<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:35:"./templete/default/index_index.html";i:1608189482;}*/ ?>
<!--
 * @Title: 
 * @Author: wzs
 * @Date: 2020-06-16 13:06:09
 * @LastEditors: wzs
 * @LastEditTime: 2020-06-16 23:29:18
 * @Description: 
-->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Document</title>
  <script src="/public/static/socket.io.js"></script>
  <script src="/public/static/layui/layui.js"></script>
</head>

<body>
  <script id="demo" type="text/html">
    {{#  layui.each(d, function(index, item){ }}
    <li>
      <div class="index">
        <div>{{zero(index + 1)}}</div>
      </div>
      <div class="license">
        <div>{{item.license}}</div>
      </div>
    </li>
    {{#  }); }}
  </script>
  <script>
    layui.use(["jquery", "laytpl"], function () {
      var $ = layui.jquery,
        laytpl = layui.laytpl,
        getTpl = demo.innerHTML;
      $("document").ready(function () {
        var socket = io("http://"+window.location.host+":2120"),
          uid = 'wzs',
          room = 3,
          getData,
          init;
        socket.on("connect", function () {
          socket.emit("login", uid);
          socket.emit("join", uid, room);
        });

        // 后端推送来消息时
        socket.on("new_msg", function (msg) {
          // getData();
          console.log(msg)
        });
        init = (function () {

        })();
      });
    });
  </script>
</body>

</html>