<?php
//000000000000
 exit();?>
a:1:{i:0;a:14:{s:2:"id";i:222;s:11:"category_id";i:9;s:11:"description";s:6:"文章";s:4:"icon";N;s:4:"name";s:6:"文章";s:4:"path";s:13:"article/index";s:3:"pid";i:42;s:4:"sort";i:99;s:6:"status";i:1;s:4:"type";i:1;s:8:"moduleid";i:39;s:6:"ismenu";i:1;s:3:"url";s:0:"";s:8:"pagesize";i:0;}}