<?php
//000000000000
 exit();?>
a:14:{s:4:"p_id";a:21:{s:2:"id";i:231;s:8:"moduleid";i:41;s:5:"field";s:4:"p_id";s:4:"name";s:6:"栏目";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:1;s:9:"maxlength";i:6;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:24:"必须选择一个栏目";s:5:"class";s:4:"p_id";s:4:"type";s:4:"p_id";s:5:"setup";s:0:"";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:0;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";i:0;}s:4:"name";a:21:{s:2:"id";i:234;s:8:"moduleid";i:41;s:5:"field";s:4:"name";s:4:"name";s:12:"系统名称";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:4:"name";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:0;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:3:"url";a:21:{s:2:"id";i:235;s:8:"moduleid";i:41;s:5:"field";s:3:"url";s:4:"name";s:12:"网站地址";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:3:"url";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:0;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:5:"title";a:21:{s:2:"id";i:236;s:8:"moduleid";i:41;s:5:"field";s:5:"title";s:4:"name";s:12:"网站名称";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:5:"title";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:0;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:8:"keywords";a:21:{s:2:"id";i:237;s:8:"moduleid";i:41;s:5:"field";s:8:"keywords";s:4:"name";s:9:"关键字";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:8:"keywords";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:0;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:4:"desc";a:21:{s:2:"id";i:238;s:8:"moduleid";i:41;s:5:"field";s:4:"desc";s:4:"name";s:6:"描述";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:4:"desc";s:4:"type";s:8:"textarea";s:5:"setup";s:59:"array (
  'fieldtype' => 'mediumtext',
  'default' => '',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:0;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:5:"beian";a:21:{s:2:"id";i:239;s:8:"moduleid";i:41;s:5:"field";s:5:"beian";s:4:"name";s:9:"备案号";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:5:"beian";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:0;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:9:"copyright";a:21:{s:2:"id";i:240;s:8:"moduleid";i:41;s:5:"field";s:9:"copyright";s:4:"name";s:9:"Copyright";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:9:"copyright";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:0;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:7:"address";a:21:{s:2:"id";i:241;s:8:"moduleid";i:41;s:5:"field";s:7:"address";s:4:"name";s:6:"地址";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:7:"address";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:0;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:3:"tel";a:21:{s:2:"id";i:242;s:8:"moduleid";i:41;s:5:"field";s:3:"tel";s:4:"name";s:6:"电话";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:3:"tel";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:0;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:5:"email";a:21:{s:2:"id";i:243;s:8:"moduleid";i:41;s:5:"field";s:5:"email";s:4:"name";s:6:"邮箱";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:5:"email";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:0;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:4:"logo";a:21:{s:2:"id";i:244;s:8:"moduleid";i:41;s:5:"field";s:4:"logo";s:4:"name";s:4:"LOGO";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:4:"logo";s:4:"type";s:5:"image";s:5:"setup";s:68:"array (
  'upload_allowext' => 'jpg|jpeg|gif|png',
  'info' => '',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:0;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:10:"createtime";a:21:{s:2:"id";i:232;s:8:"moduleid";i:41;s:5:"field";s:10:"createtime";s:4:"name";s:12:"发布时间";s:4:"tips";s:0:"";s:8:"required";i:0;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:4:"date";s:8:"errormsg";s:0:"";s:5:"class";s:10:"createtime";s:4:"type";s:8:"datetime";s:5:"setup";s:35:"array (
  'option' => 'datetime',
)";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:97;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";i:0;}s:6:"status";a:21:{s:2:"id";i:233;s:8:"moduleid";i:41;s:5:"field";s:6:"status";s:4:"name";s:6:"状态";s:4:"tips";s:0:"";s:8:"required";i:0;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:0:"";s:8:"errormsg";s:0:"";s:5:"class";s:0:"";s:4:"type";s:5:"radio";s:5:"setup";s:140:"array (
  'options' => '发布|1保存|0',
  'fieldtype' => 'tinyint',
  'numbertype' => '1',
  'labelwidth' => '75',
  'default' => '1',
)";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:98;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";i:0;}}