<?php
//000000000000
 exit();?>
a:9:{s:4:"p_id";a:21:{s:2:"id";i:219;s:8:"moduleid";i:39;s:5:"field";s:4:"p_id";s:4:"name";s:6:"栏目";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:1;s:9:"maxlength";i:6;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:24:"必须选择一个栏目";s:5:"class";s:4:"p_id";s:4:"type";s:5:"catid";s:5:"setup";s:0:"";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:1;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";i:0;}s:5:"title";a:21:{s:2:"id";i:220;s:8:"moduleid";i:39;s:5:"field";s:5:"title";s:4:"name";s:6:"标题";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:1;s:9:"maxlength";i:80;s:7:"pattern";s:0:"";s:8:"errormsg";s:28:"标题必须为1-80个字符";s:5:"class";s:0:"";s:4:"type";s:5:"title";s:5:"setup";s:63:"array (
  'thumb' => '1',
  'style' => '1',
  'size' => '55',
)";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:2;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:1;s:8:"issearch";i:1;s:7:"istotal";i:0;}s:8:"keywords";a:21:{s:2:"id";i:221;s:8:"moduleid";i:39;s:5:"field";s:8:"keywords";s:4:"name";s:12:"SEO关键词";s:4:"tips";s:0:"";s:8:"required";i:0;s:9:"minlength";i:0;s:9:"maxlength";i:80;s:7:"pattern";s:0:"";s:8:"errormsg";s:0:"";s:5:"class";s:0:"";s:4:"type";s:4:"text";s:5:"setup";s:97:"array (
  'size' => '55',
  'default' => '',
  'ispassword' => '0',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:3;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";i:0;}s:11:"description";a:21:{s:2:"id";i:222;s:8:"moduleid";i:39;s:5:"field";s:11:"description";s:4:"name";s:9:"SEO描述";s:4:"tips";s:0:"";s:8:"required";i:0;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:0:"";s:8:"errormsg";s:0:"";s:5:"class";s:0:"";s:4:"type";s:8:"textarea";s:5:"setup";s:94:"array (
  'fieldtype' => 'mediumtext',
  'rows' => '4',
  'cols' => '55',
  'default' => '',
)";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:4;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";i:0;}s:7:"content";a:21:{s:2:"id";i:223;s:8:"moduleid";i:39;s:5:"field";s:7:"content";s:4:"name";s:6:"内容";s:4:"tips";s:0:"";s:8:"required";i:0;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:7:"content";s:4:"type";s:6:"editor";s:5:"setup";s:36:"array (
  'edittype' => 'UEditor',
)";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:5;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";i:0;}s:4:"sort";a:21:{s:2:"id";i:289;s:8:"moduleid";i:39;s:5:"field";s:4:"sort";s:4:"name";s:6:"排序";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:4:"sort";s:4:"type";s:4:"text";s:5:"setup";s:97:"array (
  'default' => '50',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:6;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:1;s:8:"issearch";i:0;s:7:"istotal";N;}s:5:"posid";a:21:{s:2:"id";i:226;s:8:"moduleid";i:39;s:5:"field";s:5:"posid";s:4:"name";s:9:"推荐位";s:4:"tips";s:0:"";s:8:"required";i:0;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:0:"";s:8:"errormsg";s:0:"";s:5:"class";s:0:"";s:4:"type";s:5:"posid";s:5:"setup";s:0:"";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:12;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";i:0;}s:10:"createtime";a:21:{s:2:"id";i:224;s:8:"moduleid";i:39;s:5:"field";s:10:"createtime";s:4:"name";s:12:"发布时间";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:4:"date";s:8:"errormsg";s:0:"";s:5:"class";s:10:"createtime";s:4:"type";s:8:"datetime";s:5:"setup";s:35:"array (
  'option' => 'datetime',
)";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:97;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:1;s:8:"issearch";i:1;s:7:"istotal";i:0;}s:6:"status";a:21:{s:2:"id";i:225;s:8:"moduleid";i:39;s:5:"field";s:6:"status";s:4:"name";s:6:"状态";s:4:"tips";s:0:"";s:8:"required";i:0;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:0:"";s:8:"errormsg";s:0:"";s:5:"class";s:0:"";s:4:"type";s:5:"radio";s:5:"setup";s:140:"array (
  'options' => '发布|1保存|0',
  'fieldtype' => 'tinyint',
  'numbertype' => '1',
  'labelwidth' => '75',
  'default' => '1',
)";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:98;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";i:0;}}