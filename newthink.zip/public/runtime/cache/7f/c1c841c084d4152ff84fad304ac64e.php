<?php
//000000000000
 exit();?>
a:7:{s:4:"p_id";a:21:{s:2:"id";i:253;s:8:"moduleid";i:43;s:5:"field";s:4:"p_id";s:4:"name";s:6:"栏目";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:1;s:9:"maxlength";i:6;s:7:"pattern";s:0:"";s:8:"errormsg";s:24:"必须选择一个栏目";s:5:"class";s:0:"";s:4:"type";s:4:"p_id";s:5:"setup";s:0:"";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:1;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:1;s:8:"issearch";i:1;s:7:"istotal";i:0;}s:6:"server";a:21:{s:2:"id";i:256;s:8:"moduleid";i:43;s:5:"field";s:6:"server";s:4:"name";s:9:"服务器";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:6:"server";s:4:"type";s:4:"text";s:5:"setup";s:123:"array (
  'default' => 'http://api.qirui.com:7891/mt',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:2;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:6:"apikey";a:21:{s:2:"id";i:257;s:8:"moduleid";i:43;s:5:"field";s:6:"apikey";s:4:"name";s:6:"ApiKey";s:4:"tips";s:0:"";s:8:"required";i:0;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:6:"apikey";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:3;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:9:"apisecret";a:21:{s:2:"id";i:258;s:8:"moduleid";i:43;s:5:"field";s:9:"apisecret";s:4:"name";s:9:"ApiSecret";s:4:"tips";s:0:"";s:8:"required";i:0;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:9:"apisecret";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:4;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:9:"autograph";a:21:{s:2:"id";i:259;s:8:"moduleid";i:43;s:5:"field";s:9:"autograph";s:4:"name";s:12:"短信签名";s:4:"tips";s:0:"";s:8:"required";i:0;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:9:"autograph";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:5;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:10:"createtime";a:21:{s:2:"id";i:254;s:8:"moduleid";i:43;s:5:"field";s:10:"createtime";s:4:"name";s:12:"发布时间";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:4:"date";s:8:"errormsg";s:0:"";s:5:"class";s:0:"";s:4:"type";s:8:"datetime";s:5:"setup";s:35:"array (
  'option' => 'datetime',
)";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:97;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:1;s:8:"issearch";i:1;s:7:"istotal";i:0;}s:6:"status";a:21:{s:2:"id";i:255;s:8:"moduleid";i:43;s:5:"field";s:6:"status";s:4:"name";s:6:"状态";s:4:"tips";s:0:"";s:8:"required";i:0;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:0:"";s:8:"errormsg";s:0:"";s:5:"class";s:0:"";s:4:"type";s:5:"radio";s:5:"setup";s:140:"array (
  'options' => '发布|1保存|0',
  'fieldtype' => 'tinyint',
  'numbertype' => '1',
  'labelwidth' => '75',
  'default' => '1',
)";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:98;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";i:0;}}