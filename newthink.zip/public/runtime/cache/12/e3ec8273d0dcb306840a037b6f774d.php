<?php
//000000000000
 exit();?>
a:12:{s:4:"p_id";a:21:{s:2:"id";i:275;s:8:"moduleid";i:46;s:5:"field";s:4:"p_id";s:4:"name";s:6:"栏目";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:1;s:9:"maxlength";i:6;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:24:"必须选择一个栏目";s:5:"class";s:4:"p_id";s:4:"type";s:4:"p_id";s:5:"setup";s:0:"";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:1;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";i:0;}s:9:"nick_name";a:21:{s:2:"id";i:278;s:8:"moduleid";i:46;s:5:"field";s:9:"nick_name";s:4:"name";s:12:"微信昵称";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:9:"nick_name";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:2;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:1;s:8:"issearch";i:1;s:7:"istotal";N;}s:4:"name";a:21:{s:2:"id";i:279;s:8:"moduleid";i:46;s:5:"field";s:4:"name";s:4:"name";s:6:"姓名";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:4:"name";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:3;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:3:"tel";a:21:{s:2:"id";i:286;s:8:"moduleid";i:46;s:5:"field";s:3:"tel";s:4:"name";s:9:"手机号";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:3:"tel";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:3;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:1;s:8:"issearch";i:1;s:7:"istotal";N;}s:6:"openid";a:21:{s:2:"id";i:280;s:8:"moduleid";i:46;s:5:"field";s:6:"openid";s:4:"name";s:6:"openId";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:6:"openid";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:4;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:1;s:8:"issearch";i:0;s:7:"istotal";N;}s:6:"gender";a:21:{s:2:"id";i:281;s:8:"moduleid";i:46;s:5:"field";s:6:"gender";s:4:"name";s:6:"性别";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:6:"gender";s:4:"type";s:5:"radio";s:5:"setup";s:119:"array (
  'options' => '未知|0
男|1
女|2',
  'fieldtype' => 'varchar',
  'numbertype' => '1',
  'default' => '0',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:5;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:1;s:8:"issearch";i:0;s:7:"istotal";N;}s:7:"country";a:21:{s:2:"id";i:284;s:8:"moduleid";i:46;s:5:"field";s:7:"country";s:4:"name";s:6:"国家";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:7:"country";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:6;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:8:"province";a:21:{s:2:"id";i:283;s:8:"moduleid";i:46;s:5:"field";s:8:"province";s:4:"name";s:3:"省";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:8:"province";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:7;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:4:"city";a:21:{s:2:"id";i:282;s:8:"moduleid";i:46;s:5:"field";s:4:"city";s:4:"name";s:6:"城市";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:4:"city";s:4:"type";s:4:"text";s:5:"setup";s:95:"array (
  'default' => '',
  'ispassword' => '0',
  'info' => '',
  'fieldtype' => 'varchar',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:8;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:9:"avatarUrl";a:21:{s:2:"id";i:285;s:8:"moduleid";i:46;s:5:"field";s:9:"avatarUrl";s:4:"name";s:6:"头像";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:6:"defaul";s:8:"errormsg";s:0:"";s:5:"class";s:9:"avatarUrl";s:4:"type";s:5:"image";s:5:"setup";s:68:"array (
  'upload_allowext' => 'jpg|jpeg|gif|png',
  'info' => '',
)";s:6:"ispost";i:0;s:11:"unpostgroup";s:0:"";s:4:"sort";i:9;s:6:"status";i:1;s:8:"issystem";i:0;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";N;}s:10:"createtime";a:21:{s:2:"id";i:276;s:8:"moduleid";i:46;s:5:"field";s:10:"createtime";s:4:"name";s:12:"注册时间";s:4:"tips";s:0:"";s:8:"required";i:1;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:4:"date";s:8:"errormsg";s:0:"";s:5:"class";s:10:"createtime";s:4:"type";s:8:"datetime";s:5:"setup";s:35:"array (
  'option' => 'datetime',
)";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:97;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:1;s:8:"issearch";i:1;s:7:"istotal";i:0;}s:6:"status";a:21:{s:2:"id";i:277;s:8:"moduleid";i:46;s:5:"field";s:6:"status";s:4:"name";s:6:"状态";s:4:"tips";s:0:"";s:8:"required";i:0;s:9:"minlength";i:0;s:9:"maxlength";i:0;s:7:"pattern";s:0:"";s:8:"errormsg";s:0:"";s:5:"class";s:0:"";s:4:"type";s:5:"radio";s:5:"setup";s:140:"array (
  'options' => '发布|1保存|0',
  'fieldtype' => 'tinyint',
  'numbertype' => '1',
  'labelwidth' => '75',
  'default' => '1',
)";s:6:"ispost";i:1;s:11:"unpostgroup";s:0:"";s:4:"sort";i:98;s:6:"status";i:1;s:8:"issystem";i:1;s:6:"islist";i:0;s:8:"issearch";i:0;s:7:"istotal";i:0;}}