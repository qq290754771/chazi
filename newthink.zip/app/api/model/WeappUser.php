<?php
/*
 * @Title: 小程序
 * @Author: wzs
 * @Date: 2020-05-28 14:31:36
 * @LastEditors: wzs
 * @LastEditTime: 2020-05-28 15:55:10
 * @Description: 
 */ 
namespace app\api\model;

use think\Model;

class WeappUser extends Model
{
    protected $table = 'cool_weapp_member';
}