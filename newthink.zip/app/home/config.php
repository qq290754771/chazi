<?php
return [
    'template'               => [
        // 模板文件名分隔符
        'view_depr'    => '_',
        'taglib_pre_load'    => 'app\common\taglib\Cool',
    ]
];
